-- SICA - Esquema de base de datos (PostgreSQL)
-- Ejecutar este script antes de iniciar la aplicación.

DROP TABLE IF EXISTS bitacora_auditoria CASCADE;
DROP TABLE IF EXISTS incidente CASCADE;
DROP TABLE IF EXISTS visita CASCADE;
DROP TABLE IF EXISTS rol_permiso CASCADE;
DROP TABLE IF EXISTS usuario CASCADE;
DROP TABLE IF EXISTS persona CASCADE;
DROP TABLE IF EXISTS empresa CASCADE;
DROP TABLE IF EXISTS permiso CASCADE;
DROP TABLE IF EXISTS rol CASCADE;

CREATE TABLE rol (
    id          BIGSERIAL PRIMARY KEY,
    nombre      VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE permiso (
    id          BIGSERIAL PRIMARY KEY,
    codigo      VARCHAR(50) NOT NULL UNIQUE,
    descripcion VARCHAR(255)
);

CREATE TABLE rol_permiso (
    rol_id      BIGINT NOT NULL REFERENCES rol(id) ON DELETE CASCADE,
    permiso_id  BIGINT NOT NULL REFERENCES permiso(id) ON DELETE CASCADE,
    PRIMARY KEY (rol_id, permiso_id)
);

CREATE TABLE empresa (
    id          BIGSERIAL PRIMARY KEY,
    nombre      VARCHAR(150) NOT NULL,
    nit         VARCHAR(30) NOT NULL UNIQUE
);

CREATE TABLE persona (
    id              BIGSERIAL PRIMARY KEY,
    tipo            VARCHAR(20) NOT NULL CHECK (tipo IN ('TRABAJADOR', 'INVITADO')),
    nombre          VARCHAR(150) NOT NULL,
    documento       VARCHAR(30) NOT NULL UNIQUE,
    foto_url        VARCHAR(500),
    empresa_id      BIGINT REFERENCES empresa(id),
    bloqueado       BOOLEAN NOT NULL DEFAULT FALSE,
    motivo_bloqueo  VARCHAR(255)
);

CREATE TABLE usuario (
    id              BIGSERIAL PRIMARY KEY,
    username        VARCHAR(50) NOT NULL UNIQUE,
    password_hash   VARCHAR(255) NOT NULL,
    activo          BOOLEAN NOT NULL DEFAULT TRUE,
    rol_id          BIGINT NOT NULL REFERENCES rol(id),
    persona_id      BIGINT REFERENCES persona(id)
);

CREATE TABLE visita (
    id                          BIGSERIAL PRIMARY KEY,
    persona_id                  BIGINT NOT NULL REFERENCES persona(id),
    empresa_destino_id          BIGINT NOT NULL REFERENCES empresa(id),
    funcionario_anfitrion_id    BIGINT REFERENCES usuario(id),
    guarda_id                   BIGINT NOT NULL REFERENCES usuario(id),
    estado                      VARCHAR(30) NOT NULL,
    es_pase_temporal            BOOLEAN NOT NULL DEFAULT FALSE,
    fecha_hora_registro         TIMESTAMP NOT NULL,
    fecha_hora_entrada          TIMESTAMP,
    fecha_hora_salida           TIMESTAMP,
    observaciones               VARCHAR(500)
);

CREATE TABLE incidente (
    id                      BIGSERIAL PRIMARY KEY,
    persona_id              BIGINT REFERENCES persona(id),
    visita_id               BIGINT REFERENCES visita(id),
    usuario_registra_id     BIGINT NOT NULL REFERENCES usuario(id),
    tipo                    VARCHAR(100) NOT NULL,
    descripcion             VARCHAR(500),
    fecha_hora              TIMESTAMP NOT NULL
);

CREATE TABLE bitacora_auditoria (
    id                  BIGSERIAL PRIMARY KEY,
    usuario_id          BIGINT REFERENCES usuario(id),
    accion              VARCHAR(100) NOT NULL,
    entidad_afectada    VARCHAR(100) NOT NULL,
    entidad_id          BIGINT,
    detalle             VARCHAR(500),
    resultado           VARCHAR(20) NOT NULL CHECK (resultado IN ('EXITOSO', 'FALLIDO')),
    fecha_hora          TIMESTAMP NOT NULL
);

CREATE INDEX idx_persona_documento ON persona(documento);
CREATE INDEX idx_visita_estado ON visita(estado);
CREATE INDEX idx_visita_persona ON visita(persona_id);
CREATE INDEX idx_bitacora_fecha ON bitacora_auditoria(fecha_hora);
