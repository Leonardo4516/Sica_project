-- SICA - Datos semilla
-- Ejecutar después de schema.sql

-- ROLES
INSERT INTO rol (id, nombre) VALUES
    (1, 'ADMIN'),
    (2, 'GUARDA'),
    (3, 'FUNCIONARIO');

-- PERMISOS
INSERT INTO permiso (id, codigo, descripcion) VALUES
    (1, 'registrar_visita',      'Registrar el ingreso de una persona'),
    (2, 'registrar_salida',      'Registrar la salida de una persona'),
    (3, 'ver_visitantes',        'Consultar visitantes y su estado actual'),
    (4, 'aprobar_visita',        'Aprobar una solicitud de acceso pendiente'),
    (5, 'rechazar_visita',       'Rechazar una solicitud de acceso pendiente'),
    (6, 'ver_solicitudes',       'Ver solicitudes de acceso pendientes de aprobación'),
    (7, 'generar_reporte',       'Generar reportes de auditoría y trazabilidad'),
    (8, 'bloquear_persona',      'Marcar a una persona con restricción de acceso'),
    (9, 'desbloquear_persona',   'Retirar una restricción de acceso'),
    (10, 'gestionar_usuarios',   'Crear, editar o desactivar usuarios del sistema'),
    (11, 'ver_todas_las_visitas','Ver el historial completo de visitas del complejo'),
    (12, 'registrar_incidente',  'Registrar un incidente de seguridad');

-- ROL_PERMISO (RBAC: qué puede hacer cada rol)
INSERT INTO rol_permiso (rol_id, permiso_id) VALUES
    -- GUARDA
    (2, 1), (2, 2), (2, 3), (2, 12),
    -- FUNCIONARIO
    (3, 4), (3, 5), (3, 6),
    -- ADMIN (todos los permisos)
    (1, 1), (1, 2), (1, 3), (1, 4), (1, 5), (1, 6),
    (1, 7), (1, 8), (1, 9), (1, 10), (1, 11), (1, 12);

-- EMPRESAS
INSERT INTO empresa (id, nombre, nit) VALUES
    (1, 'Zona Acme', '900123456-7'),
    (2, 'Tecnobytes SAS', '900987654-3'),
    (3, 'InnoVA Consulting', '900555555-1');

-- PERSONAS (trabajadores de ejemplo, vinculados a los usuarios de sistema)
INSERT INTO persona (id, tipo, nombre, documento, foto_url, empresa_id, bloqueado) VALUES
    (1, 'TRABAJADOR', 'Administrador SICA', '1000000001', NULL, 1, FALSE),
    (2, 'TRABAJADOR', 'Carlos Guardia',      '1000000002', NULL, 1, FALSE),
    (3, 'TRABAJADOR', 'Laura Funcionaria',   '1000000003', NULL, 2, FALSE);

-- USUARIOS (contraseñas hasheadas con BCrypt, NUNCA texto plano)
-- admin     / admin123
-- guarda    / guarda123
-- funcionario / funcionario123
INSERT INTO usuario (id, username, password_hash, activo, rol_id, persona_id) VALUES
    (1, 'admin',       '$2a$10$LM3nOk95b23zeDrdKPwhFOLxlQ5nSIpWnV0LyZtGilawA6rG6UxAG', TRUE, 1, 1),
    (2, 'guarda',      '$2a$10$2gt.navFrbGxYQk8hmKp9.9WlYby64WHCoTOqhTSGQu3LHqFBwcr2', TRUE, 2, 2),
    (3, 'funcionario', '$2a$10$Vi95ETbNyt3Z8DpY4OiIZ.WGA1Y4gOtRZ8h8asTYVa1tciCo09.9S', TRUE, 3, 3);

-- Reiniciar secuencias para que los próximos inserts por la app no choquen con estos IDs fijos
SELECT setval('rol_id_seq', 3);
SELECT setval('permiso_id_seq', 12);
SELECT setval('empresa_id_seq', 3);
SELECT setval('persona_id_seq', 3);
SELECT setval('usuario_id_seq', 3);
